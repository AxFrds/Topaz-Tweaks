### v1.1 (23-09-2023)
* Optimize memory
* Auto fstrim
* Unlock ultra ML

### v1.0 (23-09-2023)
* Initial release
