### v1.3 (25-09-2023)
* Unlock 90Hz option [MIUI]
* Unlock AOD always [MIUI]
* Copy photo text from Gallery [MIUI]
* Using GPU render engine
* Using SkiaGL renderer
* Disabling VSync
* More tweaks for SurfaceFlinger
* Disable warning when increasing volume
* Fix unlock FPS Ultra Mobile Legends

### v1.2 (24-09-2023)
* Smoothing GUI
* Removing Disable Thermal

### v1.1 (23-09-2023)
* Auto fstrim
* Optimizing memory
* Unlock FPS Ultra Mobile Legends

### v1.0 (23-09-2023)
* Initial release