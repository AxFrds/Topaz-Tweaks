### v1.2 (24-09-2023)
* Add Smooth GUI
* Removing Disable Thermal

### v1.1 (23-09-2023)
* Add Optimize memory
* Add Auto fstrim
* Add Unlock ultra ML

### v1.0 (23-09-2023)
* Initial release
