#!/system/bin/sh
MODDIR=${0%/*}

# Dalvik threading
resetprop -n persist.sys.dalvik.multithread true

# Optimize memory
loop=$(cat /sys/block/zram0/backing_dev | grep -o "loop[0-30]*")
echo none > /sys/block/$loop/queue/scheduler
echo 1024 /sys/block/$loop/queue/read_ahead_kb
echo 256 /sys/block/sda/queue/read_ahead_kb
echo 256 /sys/block/sde/queue/read_ahead_kb
echo 128 /sys/block/sda/queue/nr_requests
echo 128 /sys/block/sde/queue/nr_requests
echo 2 /sys/block/sda/queue/rq_affinity
echo 2 /sys/block/sde/queue/rq_affinity
echo 0 /proc/sys/vm/overcommit_memory
change_task "kswapd" "fe" "-2"
change_task "oom_reaper" "8" "-2"
echo true > /sys/kernel/mm/swap/vma_ra_enabled
echo 2 /proc/sys/vm/page-cluster
echo 0 /proc/sys/vm/compact_unevictable_allowed
echo 500 /proc/sys/vm/extfrag_threshold
change_task(){
	local ps_ret="$(ps -Ao pid,args)"
	for temp_pid in $(echo "$ps_ret" | grep "$1" | awk '{print $1}'); do
		for temp_tid in $(ls "/proc/$temp_pid/task/"); do
			taskset -p "$2" "$temp_tid"
			renice "$3" -p "$temp_tid"
		done
	done
}

# Filesystem trim
fstrim -v /cache
fstrim -v /data
fstrim -v /metadata
fstrim -v /odm
fstrim -v /product
fstrim -v /system
fstrim -v /system_dlkm
fstrim -v /system_ext
fstrim -v /vendor
fstrim -v /vendor_dlkm

# Smooth GUI
android_properties=(
persist.sys.lgospd.enable=0
persist.sys.pcsync.enable=0
persist.sys.scrollingcache=2
ro.max.fling_velocity=20000
ro.min.fling_velocity=8000
ro.min_pointer_dur=8
sys.use_fifo_ui=1
windowsmgr.max_event_per_sec=200
)

for prop in "${android_properties[@]}"; do
	resetprop -n "${prop%=*}" "${prop#*=}"
done

# More setprop
setprop hw3d.force 1
setprop hwui.disable_vsync true
setprop debug.composition.type gpu
setprop debug.hwui.renderer skiagl
setprop debug.renderengine.backend skiagl
setprop debug.renderengine.backend skiaglthreaded
setprop debug.gr.swapinterval 60
setprop debug.gr.numframebuffers 3
setprop debug.overlayui.enable 1
setprop debug.egl.buffcount 4
setprop debug.egl.hw 1
setprop debug.performance.tuning 1
setprop debug.sf.hw 1
setprop debug.sf.set_idle_timer_ms 30
setprop debug.sf.disable_backpressure 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.enable_hwc_vds 1
setprop debug.sf.early_phase_offset_ns 500000
setprop debug.sf.early_app_phase_offset_ns 500000
setprop debug.sf.early_gl_phase_offset_ns 3000000
setprop debug.sf.early_gl_app_phase_offset_ns 15000000
setprop debug.sf.high_fps_early_phase_offset_ns 6100000
setprop debug.sf.high_fps_late_sf_phase_offset_ns 8000000
setprop debug.sf.high_fps_early_gl_phase_offset_ns 9000000
setprop debug.sf.high_fps_late_app_phase_offset_ns 1000000
setprop debug.sf.high_fps_late_sf_phase_offset_ns 8000000
setprop debug.sf.high_fps_early_gl_phase_offset_ns 9000000
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000
