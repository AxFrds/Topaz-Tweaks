#!/system/bin/sh
MODDIR=${0%/*}

# Disable Thermal
THERMAL

# Dalvik
resetprop -n persist.sys.dalvik.multithread true

# Optimize Memory
loop=$(cat /sys/block/zram0/backing_dev | grep -o "loop[0-30]*")
echo none > /sys/block/$loop/queue/scheduler
echo 1024 /sys/block/$loop/queue/read_ahead_kb
echo 256 /sys/block/sda/queue/read_ahead_kb
echo 256 /sys/block/sde/queue/read_ahead_kb
echo 128 /sys/block/sda/queue/nr_requests
echo 128 /sys/block/sde/queue/nr_requests
echo 2 /sys/block/sda/queue/rq_affinity
echo 2 /sys/block/sde/queue/rq_affinity
echo 0 /proc/sys/vm/overcommit_memory
change_task "kswapd" "fe" "-2"
change_task "oom_reaper" "8" "-2"
echo true > /sys/kernel/mm/swap/vma_ra_enabled
echo 2 /proc/sys/vm/page-cluster
echo 0 /proc/sys/vm/compact_unevictable_allowed
echo 500 /proc/sys/vm/extfrag_threshold
am force-stop com.miui.micloudsync
am force-stop com.miui.cloudservice
am force-stop com.android.thememanager
am force-stop com.xiaomi.account
am force-stop com.miui.voiceassist
am force-stop com.xiaomi.market
change_task(){
	local ps_ret="$(ps -Ao pid,args)"
	for temp_pid in $(echo "$ps_ret" | grep "$1" | awk '{print $1}'); do
		for temp_tid in $(ls "/proc/$temp_pid/task/"); do
			taskset -p "$2" "$temp_tid"
			renice "$3" -p "$temp_tid"
		done
	done
}

# Auto FStrim
fstrim -v /cache
fstrim -v /data
fstrim -v /metadata
fstrim -v /odm
fstrim -v /product
fstrim -v /system
fstrim -v /system_dlkm
fstrim -v /system_ext
fstrim -v /vendor
fstrim -v /vendor_dlkm