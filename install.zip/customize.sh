##########################################################################################
#
# MMT Extended Config Script
#
##########################################################################################

##########################################################################################
# Config Flags
##########################################################################################

# Uncomment and change 'MINAPI' and 'MAXAPI' to the minimum and maximum android version for your mod
# Uncomment DYNLIB if you want libs installed to vendor for oreo+ and system for anything older
# Uncomment PARTOVER if you have a workaround in place for extra partitions in regular magisk install (can mount them yourself - you will need to do this each boot as well). If unsure, keep commented
# Uncomment PARTITIONS and list additional partitions you will be modifying (other than system and vendor), for example: PARTITIONS="/odm /product /system_ext"
#MINAPI=21
#MAXAPI=25
#DYNLIB=true
#PARTOVER=true
#PARTITIONS=""

##########################################################################################
# Replace list
##########################################################################################

# List all directories you want to directly replace in the system
# Check the documentations for more info why you would need this

# Construct your list in the following format
# This is an example
REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here
REPLACE="
"

##########################################################################################
# Permissions
##########################################################################################

set_permissions() {
  : # Remove this if adding to this function

  # Note that all files/folders in magisk module directory have the $MODPATH prefix - keep this prefix on all of your files/folders
  # Some examples:

  # For directories (includes files in them):
  # set_perm_recursive  <dirname>                <owner> <group> <dirpermission> <filepermission> <contexts> (default: u:object_r:system_file:s0)

  # set_perm_recursive $MODPATH/system/lib 0 0 0755 0644
  # set_perm_recursive $MODPATH/system/vendor/lib/soundfx 0 0 0755 0644
  set_perm_recursive $MODPATH 0 0 0777 0777

  # For files (not in directories taken care of above)
  # set_perm  <filename>                         <owner> <group> <permission> <contexts> (default: u:object_r:system_file:s0)

  # set_perm $MODPATH/system/lib/libart.so 0 0 0644
  # set_perm /data/local/tmp/file.txt 0 0 644
}

##########################################################################################
# MMT Extended Logic - Don't modify anything after this
##########################################################################################

SKIPUNZIP=0
# unzip -qjo "$ZIPFILE" 'common/functions.sh' -d $TMPDIR >&2
# . $TMPDIR/functions.sh

TMPDIR=$NVBASE/low_screen_touch_delay
[ -d $TMPDIR ] && rm -rf $TMPDIR
mkdir -p $TMPDIR

unzip -o "$ZIPFILE" module.prop -d $TMPDIR >&2
chmod -R 777 $TMPDIR

MODID=`grep_prop id $TMPDIR/module.prop`
rm -rf $TMPDIR

vendorprop_systemlib64() {
mkdir -p $NVBASE/modules_update/$MODID/system/
mkdir -p $NVBASE/modules_update/$MODID/system/vendor/
mkdir -p $NVBASE/modules_update/$MODID/system/lib64
cp /vendor/build.prop $NVBASE/modules_update/$MODID/system/vendor/
sed -i "/offset/d" $NVBASE/modules_update/$MODID/system/vendor/build.prop
echo "debug.sf.use_phase_offsets_as_durations=1" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
echo "debug.sf.late.app.duration=16600000" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
echo "debug.sf.late.sf.duration=10500000" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
echo "debug.sf.frame_rate_multiple_threshold=120" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
echo "debug.adreno.disable_backend_affinity=true" >> $NVBASE/modules_update/$MODID/system/vendor/build.prop
}

vendorprop_systemlib64
rm -rf $TMPDIR